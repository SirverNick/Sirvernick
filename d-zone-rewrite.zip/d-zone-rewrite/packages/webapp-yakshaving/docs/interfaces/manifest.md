[yakshaving - v0.5.0](../README.md) › [Manifest](manifest.md)

# Interface: Manifest

## Hierarchy

* **Manifest**

## Index

### Properties

* [dependencies](manifest.md#dependencies)

## Properties

###  dependencies

• **dependencies**: *Record‹string, string›*

*Defined in [packages/webapp-yakshaving/source/modules/configuration/extract-information.ts:5](https://github.com/d-zone-org/d-zone/blob/ceae7d0/packages/webapp-yakshaving/source/modules/configuration/extract-information.ts#L5)*
