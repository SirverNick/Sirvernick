[yakshaving - v0.5.0](../README.md) › [YakErrorContext](yakerrorcontext.md)

# Interface: YakErrorContext

## Hierarchy

* **YakErrorContext**

## Indexable

* \[ **prop**: *string*\]: unknown

## Index

### Properties

* [internal](yakerrorcontext.md#internal)
* [isOperational](yakerrorcontext.md#isoperational)

## Properties

###  internal

• **internal**: *boolean*

*Defined in [packages/webapp-yakshaving/source/modules/utilities/error.ts:3](https://github.com/d-zone-org/d-zone/blob/ceae7d0/packages/webapp-yakshaving/source/modules/utilities/error.ts#L3)*

___

###  isOperational

• **isOperational**: *boolean*

*Defined in [packages/webapp-yakshaving/source/modules/utilities/error.ts:2](https://github.com/d-zone-org/d-zone/blob/ceae7d0/packages/webapp-yakshaving/source/modules/utilities/error.ts#L2)*
