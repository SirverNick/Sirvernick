[yakshaving - v0.5.0](../README.md) › [CacheDependencyData](cachedependencydata.md)

# Interface: CacheDependencyData

## Hierarchy

* **CacheDependencyData**
