import { TagComponent } from 'ecsy'

export default class Render extends TagComponent {}
